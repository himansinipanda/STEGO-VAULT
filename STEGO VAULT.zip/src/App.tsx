import { useState, useRef, useCallback, useEffect } from 'react';
// useEffect is used in TerminalLog component

// ─── LSB Steganography Engine ─────────────────────────────────────────────────
const DELIMITER = '<<END>>';

function encodeMessage(imageData: ImageData, message: string): ImageData {
  const data = new Uint8ClampedArray(imageData.data);
  const fullMsg = message + DELIMITER;
  const bits: number[] = [];

  for (let i = 0; i < fullMsg.length; i++) {
    const code = fullMsg.charCodeAt(i);
    for (let b = 7; b >= 0; b--) {
      bits.push((code >> b) & 1);
    }
  }

  if (bits.length > (data.length / 4) * 3) {
    throw new Error('Message too large for this image.');
  }

  let bitIndex = 0;
  for (let i = 0; i < data.length && bitIndex < bits.length; i++) {
    // Skip alpha channel (every 4th byte)
    if ((i + 1) % 4 === 0) continue;
    data[i] = (data[i] & 0xfe) | bits[bitIndex++];
  }

  return new ImageData(data, imageData.width, imageData.height);
}

function decodeMessage(imageData: ImageData): string {
  const data = imageData.data;
  let bits: number[] = [];
  let chars = '';

  for (let i = 0; i < data.length; i++) {
    if ((i + 1) % 4 === 0) continue;
    bits.push(data[i] & 1);

    if (bits.length === 8) {
      const code = bits.reduce((acc, b, idx) => acc | (b << (7 - idx)), 0);
      chars += String.fromCharCode(code);
      bits = [];

      if (chars.endsWith(DELIMITER)) {
        return chars.slice(0, -DELIMITER.length);
      }
      // Safety: stop after 10000 chars
      if (chars.length > 10000) break;
    }
  }
  return '';
}

// ─── Types ────────────────────────────────────────────────────────────────────
type Tab = 'encrypt' | 'decrypt';
type Status = 'idle' | 'processing' | 'success' | 'error';

// ─── Particle Component ───────────────────────────────────────────────────────
function Particles() {
  const particles = Array.from({ length: 20 }, (_, i) => ({
    id: i,
    left: Math.random() * 100,
    delay: Math.random() * 8,
    duration: 6 + Math.random() * 8,
    size: 2 + Math.random() * 4,
    color: i % 3 === 0 ? '#00f5ff' : i % 3 === 1 ? '#ff0090' : '#39ff14',
  }));

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {particles.map((p) => (
        <div
          key={p.id}
          className="absolute rounded-full"
          style={{
            left: `${p.left}%`,
            bottom: '-10px',
            width: p.size,
            height: p.size,
            background: p.color,
            boxShadow: `0 0 ${p.size * 3}px ${p.color}`,
            animation: `float-particle ${p.duration}s ${p.delay}s infinite linear`,
          }}
        />
      ))}
    </div>
  );
}

// ─── Matrix Rain Component ────────────────────────────────────────────────────
function MatrixSidebar({ side }: { side: 'left' | 'right' }) {
  const chars = '01アイウエオカキクケコABCDEF0123456789ΨΩΛ#@!%^&*';
  const cols = 3;
  const rows = 30;

  return (
    <div
      className="fixed top-0 bottom-0 w-16 overflow-hidden pointer-events-none z-0 opacity-20"
      style={{ [side]: 0 }}
    >
      {Array.from({ length: cols }).map((_, col) => (
        <div
          key={col}
          className="absolute top-0 text-xs leading-5 binary-stream"
          style={{
            left: col * 22,
            fontFamily: "'Share Tech Mono', monospace",
            color: '#39ff14',
            animationDuration: `${5 + col * 2}s`,
            animationDelay: `${col * 0.5}s`,
          }}
        >
          {Array.from({ length: rows * 2 }).map((_, i) => (
            <div key={i}>{chars[Math.floor(Math.random() * chars.length)]}</div>
          ))}
        </div>
      ))}
    </div>
  );
}

// ─── Logo SVG ─────────────────────────────────────────────────────────────────
function CyberLogo() {
  return (
    <div className="relative flex items-center justify-center w-20 h-20 mx-auto mb-4">
      <svg viewBox="0 0 100 100" className="w-full h-full spin-slow opacity-30 absolute">
        <circle cx="50" cy="50" r="45" fill="none" stroke="#00f5ff" strokeWidth="1" strokeDasharray="4 8" />
        <circle cx="50" cy="50" r="35" fill="none" stroke="#ff0090" strokeWidth="1" strokeDasharray="2 12" />
      </svg>
      <svg viewBox="0 0 100 100" className="w-16 h-16 relative z-10">
        <defs>
          <linearGradient id="logoGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00f5ff" />
            <stop offset="100%" stopColor="#ff0090" />
          </linearGradient>
        </defs>
        {/* Shield shape */}
        <path d="M50 5 L85 20 L85 55 Q85 80 50 95 Q15 80 15 55 L15 20 Z"
          fill="none" stroke="url(#logoGrad)" strokeWidth="2.5" />
        {/* Lock body */}
        <rect x="35" y="48" width="30" height="25" rx="3"
          fill="none" stroke="#00f5ff" strokeWidth="2" />
        {/* Lock shackle */}
        <path d="M40 48 L40 40 Q40 30 50 30 Q60 30 60 40 L60 48"
          fill="none" stroke="#ff0090" strokeWidth="2" />
        {/* Keyhole */}
        <circle cx="50" cy="57" r="4" fill="#00f5ff" opacity="0.8" />
        <rect x="48" y="57" width="4" height="8" rx="1" fill="#00f5ff" opacity="0.8" />
      </svg>
    </div>
  );
}

// ─── Upload Zone ──────────────────────────────────────────────────────────────
function UploadZone({
  label,
  preview,
  onFile,
  color = 'cyan',
}: {
  label: string;
  preview: string | null;
  onFile: (f: File) => void;
  color?: 'cyan' | 'pink';
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [drag, setDrag] = useState(false);

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setDrag(false);
      const file = e.dataTransfer.files[0];
      if (file && file.type.startsWith('image/')) onFile(file);
    },
    [onFile]
  );

  const neon = color === 'cyan' ? '#00f5ff' : '#ff0090';
  const neonAlpha = color === 'cyan' ? 'rgba(0,245,255,0.1)' : 'rgba(255,0,144,0.1)';

  return (
    <div
      className={`upload-zone relative rounded-lg p-6 flex flex-col items-center justify-center min-h-[180px] transition-all ${drag ? 'drag-over' : ''}`}
      style={{
        borderColor: drag ? neon : undefined,
        background: drag ? neonAlpha : undefined,
      }}
      onClick={() => inputRef.current?.click()}
      onDragOver={(e) => { e.preventDefault(); setDrag(true); }}
      onDragLeave={() => setDrag(false)}
      onDrop={handleDrop}
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) onFile(f);
          e.target.value = '';
        }}
      />
      {preview ? (
        <div className="relative w-full">
          <img
            src={preview}
            alt="Selected"
            className="w-full max-h-48 object-contain rounded"
            style={{ filter: 'drop-shadow(0 0 8px ' + neon + '44)' }}
          />
          <div
            className="absolute inset-0 rounded opacity-0 hover:opacity-100 flex items-center justify-center transition-all cursor-pointer"
            style={{ background: 'rgba(0,0,0,0.6)' }}
          >
            <span className="text-sm font-mono" style={{ color: neon }}>
              ▶ CHANGE IMAGE
            </span>
          </div>
        </div>
      ) : (
        <div className="text-center">
          <div className="text-4xl mb-3" style={{ filter: `drop-shadow(0 0 8px ${neon})` }}>
            {color === 'cyan' ? '📁' : '🔍'}
          </div>
          <p className="text-sm font-mono mb-1" style={{ color: neon }}>
            {label}
          </p>
          <p className="text-xs opacity-50" style={{ color: neon }}>
            DRAG & DROP OR CLICK TO BROWSE
          </p>
          <p className="text-xs opacity-30 mt-1" style={{ fontFamily: "'Share Tech Mono'" }}>
            PNG • JPG • WEBP • BMP
          </p>
        </div>
      )}
    </div>
  );
}

// ─── Terminal Log ──────────────────────────────────────────────────────────────
function TerminalLog({ lines }: { lines: string[] }) {
  const bottomRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines]);

  return (
    <div className="terminal rounded p-3 text-xs h-28 overflow-y-auto">
      {lines.map((line, i) => (
        <div key={i} className="leading-5">
          <span className="opacity-50">{'>'}</span> {line}
        </div>
      ))}
      <div className="leading-5">
        <span className="opacity-50">{'>'}</span>{' '}
        <span className="cursor-blink">█</span>
      </div>
      <div ref={bottomRef} />
    </div>
  );
}

// ─── Progress Bar ──────────────────────────────────────────────────────────────
function ProgressBar({ value }: { value: number }) {
  return (
    <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'rgba(0,245,255,0.1)' }}>
      <div
        className="h-full progress-bar rounded-full transition-all duration-500"
        style={{ width: `${value}%` }}
      />
    </div>
  );
}

// ─── Alert ────────────────────────────────────────────────────────────────────
function Alert({ type, msg }: { type: 'success' | 'error'; msg: string }) {
  const isSuccess = type === 'success';
  return (
    <div
      className="alert-animate flex items-start gap-3 p-3 rounded text-sm"
      style={{
        background: isSuccess ? 'rgba(57,255,20,0.08)' : 'rgba(255,0,0,0.08)',
        border: `1px solid ${isSuccess ? 'rgba(57,255,20,0.4)' : 'rgba(255,50,50,0.4)'}`,
        color: isSuccess ? '#39ff14' : '#ff5555',
        fontFamily: "'Share Tech Mono', monospace",
      }}
    >
      <span className="text-lg">{isSuccess ? '✓' : '✗'}</span>
      <span>{msg}</span>
    </div>
  );
}

// ─── Stats Bar ────────────────────────────────────────────────────────────────
function StatsBar({ imageInfo }: { imageInfo: { w: number; h: number; capacity: number } | null }) {
  return (
    <div className="flex gap-4 flex-wrap">
      {[
        { label: 'WIDTH', value: imageInfo ? `${imageInfo.w}px` : '---' },
        { label: 'HEIGHT', value: imageInfo ? `${imageInfo.h}px` : '---' },
        { label: 'CAPACITY', value: imageInfo ? `~${imageInfo.capacity} chars` : '---' },
        { label: 'ALGO', value: 'LSB-3CH' },
      ].map((s) => (
        <div key={s.label} className="flex-1 min-w-24 text-center p-2 rounded"
          style={{ background: 'rgba(0,245,255,0.04)', border: '1px solid rgba(0,245,255,0.1)' }}>
          <div className="text-xs opacity-50" style={{ fontFamily: "'Share Tech Mono'" }}>{s.label}</div>
          <div className="text-sm font-bold" style={{ color: '#00f5ff', fontFamily: "'Share Tech Mono'" }}>{s.value}</div>
        </div>
      ))}
    </div>
  );
}

// ─── Main App ─────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab] = useState<Tab>('encrypt');

  // ── Encrypt State
  const [encImage, setEncImage] = useState<File | null>(null);
  const [encPreview, setEncPreview] = useState<string | null>(null);
  const [encMessage, setEncMessage] = useState('');
  const [encPassword, setEncPassword] = useState('');
  const [encStatus, setEncStatus] = useState<Status>('idle');
  const [encLogs, setEncLogs] = useState<string[]>(['System ready. Awaiting input...']);
  const [encProgress, setEncProgress] = useState(0);
  const [encResult, setEncResult] = useState<string | null>(null);
  const [encAlert, setEncAlert] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [encImageInfo, setEncImageInfo] = useState<{ w: number; h: number; capacity: number } | null>(null);

  // ── Decrypt State
  const [decImage, setDecImage] = useState<File | null>(null);
  const [decPreview, setDecPreview] = useState<string | null>(null);
  const [decPassword, setDecPassword] = useState('');
  const [decStatus, setDecStatus] = useState<Status>('idle');
  const [decLogs, setDecLogs] = useState<string[]>(['System ready. Select encoded image...']);
  const [decProgress, setDecProgress] = useState(0);
  const [decResult, setDecResult] = useState<string | null>(null);
  const [decAlert, setDecAlert] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [copied, setCopied] = useState(false);

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const decCanvasRef = useRef<HTMLCanvasElement>(null);

  // ── Handle encrypt image selection
  const handleEncImage = useCallback((file: File) => {
    setEncImage(file);
    setEncResult(null);
    setEncAlert(null);
    setEncProgress(0);
    setEncLogs(['Image loaded: ' + file.name, `Size: ${(file.size / 1024).toFixed(1)} KB`]);

    const reader = new FileReader();
    reader.onload = (e) => {
      const src = e.target?.result as string;
      setEncPreview(src);

      const img = new Image();
      img.onload = () => {
        const cap = Math.floor((img.width * img.height * 3) / 8) - 10;
        setEncImageInfo({ w: img.width, h: img.height, capacity: cap });
        setEncLogs(prev => [...prev,
          `Dimensions: ${img.width}×${img.height}`,
          `Capacity: ~${cap} characters`,
          'Ready for encryption.'
        ]);
      };
      img.src = src;
    };
    reader.readAsDataURL(file);
  }, []);

  // ── Handle decrypt image selection
  const handleDecImage = useCallback((file: File) => {
    setDecImage(file);
    setDecResult(null);
    setDecAlert(null);
    setDecProgress(0);
    setDecLogs(['Encoded image loaded: ' + file.name, 'Ready for decryption.']);

    const reader = new FileReader();
    reader.onload = (e) => setDecPreview(e.target?.result as string);
    reader.readAsDataURL(file);
  }, []);

  // ── XOR cipher with password (simple obfuscation layer)
  const xorCipher = (text: string, key: string): string => {
    if (!key) return text;
    return text.split('').map((c, i) =>
      String.fromCharCode(c.charCodeAt(0) ^ key.charCodeAt(i % key.length))
    ).join('');
  };

  // ── Encrypt handler
  const handleEncrypt = async () => {
    if (!encImage || !encMessage.trim()) {
      setEncAlert({ type: 'error', msg: 'ERROR: Select an image and enter a message.' });
      return;
    }

    setEncStatus('processing');
    setEncAlert(null);
    setEncResult(null);
    setEncProgress(0);

    const logs: string[] = ['[INIT] Starting LSB encryption protocol...'];
    setEncLogs(logs);

    await sleep(300);
    logs.push('[LOAD] Loading image into memory canvas...');
    setEncLogs([...logs]);
    setEncProgress(15);

    await sleep(400);
    logs.push('[ENCODE] Applying LSB steganography algorithm...');
    setEncLogs([...logs]);
    setEncProgress(35);

    try {
      const imageData = await loadImageData(encPreview!);
      await sleep(300);
      logs.push(`[PROCESS] Encoding ${encMessage.length} characters into pixel data...`);
      setEncLogs([...logs]);
      setEncProgress(55);

      const finalMsg = encPassword ? xorCipher(encMessage, encPassword) : encMessage;
      const encoded = encodeMessage(imageData, finalMsg);

      await sleep(400);
      logs.push('[WRITE] Writing modified pixel data to canvas...');
      setEncLogs([...logs]);
      setEncProgress(75);

      const canvas = canvasRef.current!;
      canvas.width = imageData.width;
      canvas.height = imageData.height;
      const ctx = canvas.getContext('2d')!;
      ctx.putImageData(encoded, 0, 0);

      await sleep(300);
      logs.push('[EXPORT] Generating output PNG file...');
      setEncLogs([...logs]);
      setEncProgress(90);

      const dataUrl = canvas.toDataURL('image/png');
      await sleep(200);

      setEncResult(dataUrl);
      setEncProgress(100);
      logs.push('[SUCCESS] ✓ Data hidden successfully. Image ready for download!');
      if (encPassword) logs.push('[SECURE] ✓ Password protection layer applied.');
      setEncLogs([...logs]);
      setEncAlert({ type: 'success', msg: 'ENCRYPTION COMPLETE — Data hidden in image. Download the encoded file.' });
      setEncStatus('success');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      logs.push('[ERROR] ✗ ' + msg);
      setEncLogs([...logs]);
      setEncAlert({ type: 'error', msg: 'ERROR: ' + msg });
      setEncStatus('error');
    }
  };

  // ── Decrypt handler
  const handleDecrypt = async () => {
    if (!decImage) {
      setDecAlert({ type: 'error', msg: 'ERROR: Select an encoded image first.' });
      return;
    }

    setDecStatus('processing');
    setDecAlert(null);
    setDecResult(null);
    setDecProgress(0);

    const logs: string[] = ['[INIT] Starting LSB decryption protocol...'];
    setDecLogs(logs);

    await sleep(300);
    logs.push('[SCAN] Scanning pixel channel bits...');
    setDecLogs([...logs]);
    setDecProgress(20);

    await sleep(400);
    logs.push('[EXTRACT] Extracting LSB values from RGB channels...');
    setDecLogs([...logs]);
    setDecProgress(45);

    try {
      const imageData = await loadImageData(decPreview!);
      await sleep(400);
      logs.push('[DECODE] Reconstructing binary payload...');
      setDecLogs([...logs]);
      setDecProgress(65);

      const raw = decodeMessage(imageData);
      await sleep(300);

      if (!raw) {
        throw new Error('No hidden data found in this image.');
      }

      logs.push('[CIPHER] Applying decryption layer...');
      setDecLogs([...logs]);
      setDecProgress(85);
      await sleep(300);

      const finalMsg = decPassword ? xorCipher(raw, decPassword) : raw;

      setDecResult(finalMsg);
      setDecProgress(100);
      logs.push(`[SUCCESS] ✓ Hidden data extracted! (${finalMsg.length} characters)`);
      setDecLogs([...logs]);
      setDecAlert({ type: 'success', msg: 'DECRYPTION COMPLETE — Hidden message revealed.' });
      setDecStatus('success');
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Unknown error';
      logs.push('[ERROR] ✗ ' + msg);
      setDecLogs([...logs]);
      setDecAlert({ type: 'error', msg: 'ERROR: ' + msg });
      setDecStatus('error');
    }
  };

  // ── Download result
  const handleDownload = () => {
    if (!encResult) return;
    const link = document.createElement('a');
    link.href = encResult;
    link.download = `stego_encoded_${Date.now()}.png`;
    link.click();
  };

  // ── Copy to clipboard
  const handleCopy = () => {
    if (!decResult) return;
    navigator.clipboard.writeText(decResult).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  // ── Reset
  const handleEncReset = () => {
    setEncImage(null); setEncPreview(null); setEncMessage(''); setEncPassword('');
    setEncStatus('idle'); setEncProgress(0); setEncResult(null); setEncAlert(null);
    setEncImageInfo(null);
    setEncLogs(['System ready. Awaiting input...']);
  };
  const handleDecReset = () => {
    setDecImage(null); setDecPreview(null); setDecPassword('');
    setDecStatus('idle'); setDecProgress(0); setDecResult(null); setDecAlert(null);
    setDecLogs(['System ready. Select encoded image...']);
  };

  return (
    <div className="min-h-screen cyber-grid scanlines relative" style={{ background: '#020408' }}>
      <Particles />
      <MatrixSidebar side="left" />
      <MatrixSidebar side="right" />
      <canvas ref={canvasRef} className="hidden" />
      <canvas ref={decCanvasRef} className="hidden" />

      <div className="relative z-10 max-w-5xl mx-auto px-4 py-8">

        {/* ── Header ── */}
        <header className="text-center mb-10">
          <CyberLogo />
          <h1
            className="glitch-text text-5xl font-black tracking-widest mb-2"
            data-text="STEGO VAULT"
            style={{
              fontFamily: "'Orbitron', sans-serif",
              color: '#00f5ff',
              textShadow: '0 0 20px #00f5ff, 0 0 40px #00f5ff88',
            }}
          >
            STEGO VAULT
          </h1>
          <p className="text-sm tracking-widest opacity-60 mb-1" style={{ fontFamily: "'Share Tech Mono'" }}>
            ━━━ CYBER STEGANOGRAPHY ENCRYPTION SYSTEM ━━━
          </p>
          <div className="flex items-center justify-center gap-2 text-xs" style={{ fontFamily: "'Share Tech Mono'", color: '#39ff14' }}>
            <span className="status-dot active" />
            <span>SYSTEM ONLINE</span>
            <span className="opacity-40 mx-2">|</span>
            <span className="opacity-60">LSB-3CHANNEL ALGO</span>
            <span className="opacity-40 mx-2">|</span>
            <span className="opacity-60">CLIENT-SIDE ONLY</span>
          </div>
        </header>

        <hr className="cyber-hr mb-8" />

        {/* ── Tabs ── */}
        <div className="flex mb-6 rounded-lg overflow-hidden border border-white/10 relative"
          style={{ background: 'rgba(4,13,20,0.8)' }}>
          {(['encrypt', 'decrypt'] as Tab[]).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`flex-1 py-4 text-sm tracking-widest font-bold transition-all relative ${tab === t ? 'tab-active' : 'hover:bg-white/5 opacity-50 hover:opacity-80'}`}
              style={{ fontFamily: "'Orbitron', sans-serif" }}
            >
              {t === 'encrypt' ? (
                <span style={{ color: tab === 'encrypt' ? '#00f5ff' : undefined }}>
                  🔒 ENCRYPT / HIDE DATA
                </span>
              ) : (
                <span style={{ color: tab === 'decrypt' ? '#ff0090' : undefined }}>
                  🔓 DECRYPT / REVEAL DATA
                </span>
              )}
            </button>
          ))}
        </div>

        {/* ── ENCRYPT TAB ── */}
        {tab === 'encrypt' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

              {/* Left: Upload + Message */}
              <div className="space-y-4">
                {/* Panel header */}
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 rounded-full pulse-neon" style={{ background: '#00f5ff' }} />
                  <span className="text-xs tracking-widest" style={{ fontFamily: "'Share Tech Mono'", color: '#00f5ff' }}>
                    INPUT PAYLOAD
                  </span>
                </div>

                <UploadZone label="SELECT CARRIER IMAGE" preview={encPreview} onFile={handleEncImage} color="cyan" />

                <StatsBar imageInfo={encImageInfo} />

                {/* Message */}
                <div>
                  <label className="block text-xs tracking-widest mb-2 opacity-70" style={{ fontFamily: "'Share Tech Mono'", color: '#00f5ff' }}>
                    SECRET MESSAGE
                  </label>
                  <textarea
                    className="cyber-input w-full rounded p-3 resize-none text-sm"
                    rows={4}
                    placeholder="Enter your secret message here..."
                    value={encMessage}
                    onChange={(e) => setEncMessage(e.target.value)}
                    maxLength={5000}
                  />
                  <div className="flex justify-between mt-1">
                    <span className="text-xs opacity-30" style={{ fontFamily: "'Share Tech Mono'" }}>
                      {encMessage.length} / 5000 chars
                    </span>
                    {encImageInfo && (
                      <span className="text-xs" style={{
                        fontFamily: "'Share Tech Mono'",
                        color: encMessage.length > encImageInfo.capacity ? '#ff5555' : '#39ff14'
                      }}>
                        {encMessage.length > encImageInfo.capacity ? '⚠ TOO LARGE' : '✓ FITS'}
                      </span>
                    )}
                  </div>
                </div>

                {/* Password */}
                <div>
                  <label className="block text-xs tracking-widest mb-2 opacity-70" style={{ fontFamily: "'Share Tech Mono'", color: '#00f5ff' }}>
                    PASSWORD (OPTIONAL)
                  </label>
                  <input
                    type="password"
                    className="cyber-input w-full rounded p-3 text-sm"
                    placeholder="Add password protection..."
                    value={encPassword}
                    onChange={(e) => setEncPassword(e.target.value)}
                  />
                </div>
              </div>

              {/* Right: Terminal + Output */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 rounded-full pulse-neon" style={{ background: '#39ff14' }} />
                  <span className="text-xs tracking-widest" style={{ fontFamily: "'Share Tech Mono'", color: '#39ff14' }}>
                    ENCRYPTION CONSOLE
                  </span>
                </div>

                <TerminalLog lines={encLogs} />

                {encStatus === 'processing' && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs" style={{ fontFamily: "'Share Tech Mono'", color: '#00f5ff' }}>
                      <span>PROCESSING...</span>
                      <span>{encProgress}%</span>
                    </div>
                    <ProgressBar value={encProgress} />
                  </div>
                )}

                {encAlert && <Alert type={encAlert.type} msg={encAlert.msg} />}

                {/* Encoded image preview */}
                {encResult && (
                  <div className="rounded-lg overflow-hidden relative"
                    style={{ border: '1px solid rgba(57,255,20,0.3)', background: 'rgba(57,255,20,0.03)' }}>
                    <div className="p-2 text-xs text-center" style={{ fontFamily: "'Share Tech Mono'", color: '#39ff14', borderBottom: '1px solid rgba(57,255,20,0.2)' }}>
                      ✓ ENCODED OUTPUT IMAGE
                    </div>
                    <img src={encResult} alt="Encoded" className="w-full max-h-40 object-contain p-2" />
                  </div>
                )}

                {/* Action buttons */}
                <div className="flex gap-3">
                  <button
                    onClick={handleEncrypt}
                    disabled={encStatus === 'processing'}
                    className="btn-encrypt flex-1 py-3 px-4 rounded text-sm tracking-widest cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    {encStatus === 'processing' ? '⚙ ENCRYPTING...' : '🔒 ENCRYPT & HIDE'}
                  </button>
                  {encResult && (
                    <button onClick={handleDownload} className="btn-download py-3 px-4 rounded text-sm tracking-widest cursor-pointer">
                      ⬇ SAVE
                    </button>
                  )}
                  <button
                    onClick={handleEncReset}
                    className="py-3 px-4 rounded text-sm tracking-widest cursor-pointer"
                    style={{ border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.4)', fontFamily: "'Orbitron'" }}
                  >
                    ↺
                  </button>
                </div>
              </div>
            </div>

            {/* How it works */}
            <div className="rounded-lg p-4 mt-2"
              style={{ background: 'rgba(0,245,255,0.03)', border: '1px solid rgba(0,245,255,0.1)' }}>
              <div className="text-xs tracking-widest mb-3 opacity-60" style={{ fontFamily: "'Orbitron'", color: '#00f5ff' }}>
                ◈ HOW LSB STEGANOGRAPHY WORKS
              </div>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
                {[
                  { step: '01', label: 'SELECT IMAGE', desc: 'Choose any carrier PNG/JPG image' },
                  { step: '02', label: 'ENTER MESSAGE', desc: 'Type secret data to be hidden' },
                  { step: '03', label: 'ENCRYPT', desc: 'Least-Sig-Bit of each pixel is modified' },
                  { step: '04', label: 'DOWNLOAD', desc: 'Image looks identical, data is hidden' },
                ].map(s => (
                  <div key={s.step} className="text-center p-3 rounded"
                    style={{ background: 'rgba(0,245,255,0.04)', border: '1px solid rgba(0,245,255,0.08)' }}>
                    <div className="text-2xl font-black mb-1" style={{ fontFamily: "'Orbitron'", color: 'rgba(0,245,255,0.3)' }}>{s.step}</div>
                    <div className="text-xs font-bold mb-1" style={{ fontFamily: "'Orbitron'", color: '#00f5ff', fontSize: '10px' }}>{s.label}</div>
                    <div className="text-xs opacity-50" style={{ fontFamily: "'Share Tech Mono'", fontSize: '10px' }}>{s.desc}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ── DECRYPT TAB ── */}
        {tab === 'decrypt' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

              {/* Left: Upload */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 rounded-full pulse-neon" style={{ background: '#ff0090' }} />
                  <span className="text-xs tracking-widest" style={{ fontFamily: "'Share Tech Mono'", color: '#ff0090' }}>
                    ENCODED IMAGE INPUT
                  </span>
                </div>

                <UploadZone label="SELECT ENCODED IMAGE" preview={decPreview} onFile={handleDecImage} color="pink" />

                {/* Password */}
                <div>
                  <label className="block text-xs tracking-widest mb-2 opacity-70" style={{ fontFamily: "'Share Tech Mono'", color: '#ff0090' }}>
                    PASSWORD (IF PROTECTED)
                  </label>
                  <input
                    type="password"
                    className="cyber-input w-full rounded p-3 text-sm"
                    placeholder="Enter password if used during encryption..."
                    value={decPassword}
                    onChange={(e) => setDecPassword(e.target.value)}
                    style={{ borderColor: 'rgba(255,0,144,0.2)' }}
                  />
                </div>

                {/* Info panel */}
                <div className="rounded-lg p-4"
                  style={{ background: 'rgba(255,0,144,0.04)', border: '1px solid rgba(255,0,144,0.15)' }}>
                  <div className="text-xs tracking-widest mb-3" style={{ fontFamily: "'Orbitron'", color: '#ff0090', opacity: 0.8 }}>
                    ◈ DECRYPTION INFO
                  </div>
                  <ul className="space-y-2">
                    {[
                      'Upload the image you received from encoder',
                      'LSB bits are scanned from all RGB channels',
                      'Binary data reconstructed into text',
                      'Password required if used during encoding',
                    ].map((item, i) => (
                      <li key={i} className="flex gap-2 text-xs opacity-60" style={{ fontFamily: "'Share Tech Mono'" }}>
                        <span style={{ color: '#ff0090' }}>▸</span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Right: Terminal + Result */}
              <div className="space-y-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className="w-2 h-2 rounded-full pulse-neon" style={{ background: '#39ff14' }} />
                  <span className="text-xs tracking-widest" style={{ fontFamily: "'Share Tech Mono'", color: '#39ff14' }}>
                    DECRYPTION CONSOLE
                  </span>
                </div>

                <TerminalLog lines={decLogs} />

                {decStatus === 'processing' && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-xs" style={{ fontFamily: "'Share Tech Mono'", color: '#ff0090' }}>
                      <span>SCANNING...</span>
                      <span>{decProgress}%</span>
                    </div>
                    <div className="w-full h-2 rounded-full overflow-hidden" style={{ background: 'rgba(255,0,144,0.1)' }}>
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${decProgress}%`,
                          background: 'linear-gradient(90deg, #ff0090, #bf00ff, #ff0090)',
                          backgroundSize: '200% 100%',
                          animation: 'progressShimmer 2s linear infinite',
                        }}
                      />
                    </div>
                  </div>
                )}

                {decAlert && <Alert type={decAlert.type} msg={decAlert.msg} />}

                {/* Decrypted message */}
                {decResult && (
                  <div className="relative rounded-lg overflow-hidden"
                    style={{ border: '1px solid rgba(57,255,20,0.4)', background: 'rgba(0,0,0,0.5)' }}>
                    <div className="flex items-center justify-between p-3"
                      style={{ borderBottom: '1px solid rgba(57,255,20,0.2)', background: 'rgba(57,255,20,0.05)' }}>
                      <span className="text-xs tracking-widest" style={{ fontFamily: "'Share Tech Mono'", color: '#39ff14' }}>
                        ✓ DECODED MESSAGE
                      </span>
                      <button
                        onClick={handleCopy}
                        className="text-xs px-3 py-1 rounded cursor-pointer transition-all"
                        style={{
                          fontFamily: "'Share Tech Mono'",
                          border: '1px solid rgba(57,255,20,0.4)',
                          color: '#39ff14',
                          background: copied ? 'rgba(57,255,20,0.2)' : 'transparent',
                        }}
                      >
                        {copied ? '✓ COPIED' : '⎘ COPY'}
                      </button>
                    </div>
                    <div className="p-4 text-sm leading-relaxed max-h-40 overflow-y-auto"
                      style={{ fontFamily: "'Share Tech Mono'", color: '#39ff14' }}>
                      {decResult}
                    </div>
                  </div>
                )}

                <div className="flex gap-3">
                  <button
                    onClick={handleDecrypt}
                    disabled={decStatus === 'processing'}
                    className="btn-decrypt flex-1 py-3 px-4 rounded text-sm tracking-widest cursor-pointer disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    {decStatus === 'processing' ? '⚙ SCANNING...' : '🔓 DECRYPT & REVEAL'}
                  </button>
                  <button
                    onClick={handleDecReset}
                    className="py-3 px-4 rounded text-sm tracking-widest cursor-pointer"
                    style={{ border: '1px solid rgba(255,255,255,0.1)', color: 'rgba(255,255,255,0.4)', fontFamily: "'Orbitron'" }}
                  >
                    ↺
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ── Footer ── */}
        <hr className="cyber-hr mt-10 mb-6" />
        <footer className="text-center space-y-2">
          <div className="flex items-center justify-center gap-6 text-xs opacity-40 flex-wrap" style={{ fontFamily: "'Share Tech Mono'" }}>
            <span>LSB STEGANOGRAPHY ENGINE v2.0</span>
            <span>•</span>
            <span>100% CLIENT-SIDE • ZERO SERVER</span>
            <span>•</span>
            <span>CANVAS API POWERED</span>
          </div>
          <p className="text-xs opacity-20" style={{ fontFamily: "'Share Tech Mono'" }}>
            ⚠ FOR EDUCATIONAL PURPOSES ONLY ⚠
          </p>
        </footer>
      </div>
    </div>
  );
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms));
}

function loadImageData(src: string): Promise<ImageData> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d')!;
      ctx.drawImage(img, 0, 0);
      resolve(ctx.getImageData(0, 0, img.width, img.height));
    };
    img.onerror = () => reject(new Error('Failed to load image.'));
    img.src = src;
  });
}
